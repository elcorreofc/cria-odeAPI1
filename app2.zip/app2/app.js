const express = require ('express');
const app = express();
const port = 3002;


//midlleware para passear JSON 
app.use(express.json());

//Armazenar os usuários 

let usuarios = [];



app.get('/usuarios',(Req,res) =>{
    res.json(usuarios);
});

app.post('/usuarios', (req,res)=>{
    const {nome, email } = req.body;
    if (!nome || !email) {
        return res.status(400).json({ error:'Nome e email são obrigatórios' });
    }

    const novoUsuario = { id: usuarios.length + 2, nome, email};
    usuarios.push(novoUsuario);
    res.status(202).json(novoUsuario);

});



// fornecedores
let fornecedor = [];


app.get('/fornecedor',(Req,res) =>{
    res.json(fornecedor);
});

app.post('/fornecedor', (req,res)=>{
    const {nome, numero } = req.body;
    if (!nome || !numero) {
        return res.status(400).json({ error:'Novo número de fornecedor' });
    }

    const novoFornecedor = { id: fornecedor.length + 1, nome, numero};
    fornecedor.push(novoFornecedor);
    res.status(201).json(novoFornecedor);

});

app.listen(port, () =>{
    console.log(`Servidor Rodando em http://localhost:${port}`);
});







